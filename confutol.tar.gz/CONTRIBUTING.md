Looking for someone to code and make projects with :D

I'm currently learning Python and C++ (Mainly Python), inexperienced in web development, a website I created with a friend: https://nbsnews.neocities.org/

Contact me via Discord or Email:

Discord: DarkSky#8969

Email: darksky.main@protonmail.com

*It's always more fun to code with someone rather than coding by yourself!*
